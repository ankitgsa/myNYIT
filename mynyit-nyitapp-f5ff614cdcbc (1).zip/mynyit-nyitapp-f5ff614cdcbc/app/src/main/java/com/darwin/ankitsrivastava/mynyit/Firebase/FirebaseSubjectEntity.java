package com.darwin.ankitsrivastava.mynyit.Firebase;

import java.sql.Time;

/**
 * Created by DELL on 30-10-2017.
 */

public class FirebaseSubjectEntity {

private String sub_Id;
    private String sub_Name;
    private String sub_Prof;
    private String Prof_Id;
    private Time sub_Time;
    private String sub_Room;
    private String sub_Day;
    private long stud_Id;

    public FirebaseSubjectEntity() {

    }

    public String getSub_Id() {
        return sub_Id;
    }

    public void setSub_Id(String sub_Id) {
        this.sub_Id = sub_Id;
    }

    public String getSub_Name() {
        return sub_Name;
    }

    public void setSub_Name(String sub_Name) {
        this.sub_Name = sub_Name;
    }

    public String getSub_Prof() {
        return sub_Prof;
    }

    public void setSub_Prof(String sub_Prof) {
        this.sub_Prof = sub_Prof;
    }

    public String getProf_Id() {
        return Prof_Id;
    }

    public void setProf_Id(String prof_Id) {
        Prof_Id = prof_Id;
    }

    public Time getSub_Time() {
        return sub_Time;
    }

    public void setSub_Time(Time sub_Time) {
        this.sub_Time = sub_Time;
    }

    public String getSub_Room() {
        return sub_Room;
    }

    public void setSub_Room(String sub_Room) {
        this.sub_Room = sub_Room;
    }

    public String getSub_Day() {
        return sub_Day;
    }

    public void setSub_Day(String sub_Day) {
        this.sub_Day = sub_Day;
    }

    public long getStud_Id() {
        return stud_Id;
    }

    public void setStud_Id(long stud_Id) {
        this.stud_Id = stud_Id;
    }
}

package com.darwin.ankitsrivastava.mynyit;

import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class fragment_container extends AppCompatActivity implements tab1.OnFragmentInteractionListener,tab2.OnFragmentInteractionListener,tab3.OnFragmentInteractionListener,View.OnClickListener
{
TabLayout tabLayout;
    ViewPager pager;
    PagerAdapter adapter;
    EditText Student_id,subject_no,professor_name,time,day;
    Button submitButton,add_subjects;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment_container);
        tabLayout= (TabLayout) findViewById(R.id.tablayout);
        tabLayout.addTab(tabLayout.newTab().setText("Academics"));
        tabLayout.addTab(tabLayout.newTab().setText(" Finances"));
        tabLayout.addTab(tabLayout.newTab().setText("Personal Information"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        Student_id= (EditText) findViewById(R.id.Student_id);
        subject_no= (EditText) findViewById(R.id.subject_no);

        professor_name= (EditText) findViewById(R.id.professor_name);
        time= (EditText) findViewById(R.id.time);
        day= (EditText) findViewById(R.id.day);
        submitButton= (Button) findViewById(R.id.submit_button);
        add_subjects= (Button) findViewById(R.id.add_subjects);
        Log.e("fragment_container","clicked");
//submitButton.setOnClickListener(this);
      pager= (ViewPager) findViewById(R.id.pager);
adapter= new com.darwin.ankitsrivastava.mynyit.PagerAdapter(getSupportFragmentManager(),tabLayout.getTabCount());

        pager.setAdapter(adapter);
        pager.setOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
    @Override
    public void onTabSelected(TabLayout.Tab tab) {

        pager.setCurrentItem(tab.getPosition());
    }

    @Override
    public void onTabUnselected(TabLayout.Tab tab) {

    }

    @Override
    public void onTabReselected(TabLayout.Tab tab) {

    }
});
    }


    @Override
    public void onFragmentInteraction(Uri uri) {

    }

    @Override
    public void onClick(View view) {
//        if(view.equals("submit_button")){
//            Toast.makeText(getApplicationContext(),"Submit button click",Toast.LENGTH_LONG).show();
//        }
        Log.e("fragment_container","anything");


        if(view.findViewById(R.id.submit_button)==submitButton){
            Toast.makeText(getApplicationContext(),"Submit button click",Toast.LENGTH_LONG).show();
            Log.e("fragment_container","anything2");


        }

    }
}
